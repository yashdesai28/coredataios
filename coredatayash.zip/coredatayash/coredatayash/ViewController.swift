//
//  ViewController.swift
//  coredatayash
//
//  Created by bmiit on 18/03/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
        var context = NSManagedObjectContext()
    override func viewDidLoad() {
        super.viewDidLoad()
        context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Student", in: context)
               let newStudent = NSManagedObject(entity: entity!, insertInto: context)
               newStudent.setValue("John", forKey: "sname")
               newStudent.setValue(23, forKey: "age")
               newStudent.setValue(1, forKey: "sid")
        
        do{
//                   try context.save()
                    print("save")
            fetchData();
               }catch{
                   print("no save")
               }
    }
    
    
    func fetchData(){
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
        request.returnsObjectsAsFaults = false
        do{
            let result = try context.fetch(request)
            print(result[0])
            for data in result{
                print((data as AnyObject).value(forKey: "sname") as! String)
               
                print((data as AnyObject).value(forKey: "sid") as! Int16)
                print((data as AnyObject).value(forKey: "age") as! Int32)
            }
        }catch{
        }
    }


}

